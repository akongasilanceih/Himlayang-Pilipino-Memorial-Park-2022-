// These Script is for pre-loader
$(window).on('load', function () {
    $('#loading').hide();
}) 