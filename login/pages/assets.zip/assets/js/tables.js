// Script to Enable DataTable
$(document).ready( function () {
    $('#deceased-table').DataTable();
    $('#request-table').DataTable();
    $('#active-table').DataTable();
    $('#new-table').DataTable();
    $('#history-table').DataTable();
} );